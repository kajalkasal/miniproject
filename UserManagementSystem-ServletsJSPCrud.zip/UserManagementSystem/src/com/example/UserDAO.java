package com.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {

	private String jdbcURL = "jdbc:mysql://127.0.0.1:3306/java_programs";

	private String username = "root";

	private String password = "rugved2015";

	private static final String INSERT_USERS_SQL = "INSERT INTO users" + "  (name, email, country) VALUES "
			+ " (?, ?, ?);";

	private static final String SELECT_USER_BY_ID = "select id,name,email,country from users where id =?";
	private static final String SELECT_ALL_USERS = "select * from users";
	private static final String DELETE_USERS_SQL = "delete from users where id = ?;";
	private static final String UPDATE_USERS_SQL = "update users set name = ?,email= ?, country =? where id = ?;";

	Connection getConnection() {
		Connection con = null;

		try {
			// 1 Load mySql driver
			Class.forName("com.mysql.jdbc.Driver");

			System.out.println("Drivers loaded successfully");

			con = DriverManager.getConnection(jdbcURL, username, password);
			System.out.println("Connection Made.");

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return con;

	}

	public void insertUser(User user) {
		System.out.println(INSERT_USERS_SQL);

		// try with resource will auto close connection
		try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(INSERT_USERS_SQL);) {

			ps.setString(1, user.getName());
			ps.setString(2, user.getEmail());
			ps.setString(3, user.getCountry());

			ps.executeUpdate();
			System.out.println("Inserted record.");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public boolean updateUser(User user) {
		System.out.println(UPDATE_USERS_SQL);
		boolean rowUpdated = false;
		// try with resource will auto close connection
		try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(UPDATE_USERS_SQL);) {

			ps.setString(1, user.getName());
			ps.setString(2, user.getEmail());
			ps.setString(3, user.getCountry());
			ps.setInt(4, user.getId());

			int result = ps.executeUpdate();
			rowUpdated = result > 0;
			System.out.println("Record Updated Successfully.");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return rowUpdated;
	}

	public boolean deleteUser(int id) {

		boolean rowDeleted = false;
		System.out.println(DELETE_USERS_SQL);
		try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(DELETE_USERS_SQL);) {

			ps.setInt(1, id);

			int result = ps.executeUpdate();
			rowDeleted = result > 0;
			System.out.println("Record Deleted  Successfully.");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return rowDeleted;
	}

	public User selectUser(int id) {
		User user = null;
		System.out.println(SELECT_USER_BY_ID);
		try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(SELECT_USER_BY_ID);) {

			ps.setInt(1, id);

			System.out.println(ps + " prepared Statment object created for select query by id");

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				String name = rs.getString("name");
				String email = rs.getString("email");
				String country = rs.getString("country");

				user = new User(id, name, email, country);
				System.out.println("Select user by id " + id);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return user;
	}

	public List<User> selectAllUsers() {
		List<User> users = new ArrayList<User>();

		System.out.println(SELECT_ALL_USERS);
		try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(SELECT_ALL_USERS);) {

			System.out.println(ps + " prepared Statment object created for select query for all users");

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("id");
				String name = rs.getString("name");
				String email = rs.getString("email");
				String country = rs.getString("country");

				users.add(new User(id, name, email, country));
				System.out.println("user added to ArrayList");
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return users;
	}
}
